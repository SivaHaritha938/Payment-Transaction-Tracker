
CREATE DATABASE payment_db;
USE payment_db;

CREATE TABLE users (
    user_id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100)
);

CREATE TABLE transactions (
    transaction_id VARCHAR(100) PRIMARY KEY,
    user_id VARCHAR(50),
    amount DOUBLE,
    status VARCHAR(20),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);
