
import java.sql.*;
import java.util.UUID;

public class PaymentTransactionTracker {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/payment_db";
    private static final String USER = "root";
    private static final String PASS = "password";

    public static void main(String[] args) {
        addTransaction("user1", 1500.00, "SUCCESS");
    }

    public static void addTransaction(String userId, double amount, String status) {
        String transactionId = UUID.randomUUID().toString();

        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {

            String checkSql = "SELECT COUNT(*) FROM transactions WHERE transaction_id = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setString(1, transactionId);
            ResultSet rs = checkStmt.executeQuery();
            rs.next();

            if (rs.getInt(1) == 0) {
                String sql = "INSERT INTO transactions VALUES (?, ?, ?, ?)";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, transactionId);
                stmt.setString(2, userId);
                stmt.setDouble(3, amount);
                stmt.setString(4, status);
                stmt.executeUpdate();
                System.out.println("Transaction added successfully.");
            } else {
                System.out.println("Duplicate transaction detected.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
